<?
if($isIndex!=true) exit(header('Location: /'));
$status = 1;
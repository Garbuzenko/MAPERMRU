<?
header('Content-Type: text/html; charset=utf-8');
require_once $_SERVER['DOCUMENT_ROOT'].'/config.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/db.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/functions.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/lib/phpQuery.php';
$page = 'http://openapi.clearspending.ru/restapi/v3/contracts/search/?customerregion=59&budgetlevel=01&daterange=01.01.2015-02.01.2015';

$j = file_get_contents($page);
$r = json_decode($j,true);
print_r($r);

<?
if ($isIndex!=true) exit(header('Location: /'));

if (!empty($_GET['val']) && gettype($_GET['val']) != 'integer') {
    $com = clearData($_GET['val'],'get');
    
    if (file_exists($_SERVER['DOCUMENT_ROOT'].'/modules/'.$com.'/export.php'))
    require_once './modules/'.$com.'/export.php';
    
    file_download($file);
}

else
exit(header('Location: /'));
?>
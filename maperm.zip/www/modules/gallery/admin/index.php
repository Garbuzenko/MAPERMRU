<?
if($isIndex!=true) exit(header('Location: /'));

$fancybox = true;
$error = '';
$album_id = intval($_GET['a']);

if ($_POST['action'] == 'ajax') {
    
    if ($_POST['act'] == 'del_img') {
        $img_id = clearData($_POST['img_id'],'int');
        $a = db_query("DELETE FROM ".PREFIX."gallery WHERE id=$img_id LIMIT 1","d");
        if ($a===true) unlink($_SERVER['DOCUMENT_ROOT'].$_POST['img']);
    }
    
    if ($_POST['act'] == 'mainfoto') {
        $photo = $_POST['img'];
        $album_id = clearData($_POST['album_id'],'int');
        db_query("UPDATE ".PREFIX."albums SET photo='$photo' WHERE id=$album_id","u");
    }
    
    if ($_POST['act'] == 'del_album') {
        $album_id = clearData($_POST['album_id'],'int');
        $a = db_query("SELECT photo FROM ".PREFIX."gallery WHERE album_id=$album_id");
        
        if ($a != false) {
            foreach($a as $al) {
                $filename = $_SERVER['DOCUMENT_ROOT'].'/img/gallery/'.$al['photo'].'.jpg';
                if (file_exists($filename)) unlink($filename);
            }
            db_query("DELETE FROM ".PREFIX."gallery WHERE album_id=$album_id","d");
        }
        
        db_query("DELETE FROM ".PREFIX."albums WHERE id=$album_id","d");
    }
    
    exit();
}

if (!empty($_POST['add_album'])) {
    
    $title = clearData($_POST['album']);
    
    if (!empty($title)) {
        $a = db_query("INSERT INTO ".PREFIX."albums (title,date) VALUES ('$title', NOW())","i");
        if ($a == true) exit( header('Location: /admin/index.php?m=gallery') );
        else $error = '�� ���������� ������� ������. ������: '.$a;
    } 
}

if ( !empty($_POST['add_photo']) ) {
    if ( !empty( $_FILES['photo']['name'][0] ) ) {
        $val = '';
        for ($i=0;$i<count($_FILES['photo']['name']);$i++) {
            $name = $album_id.'-'.time().mt_rand(1,100000);
            $e = save_img($_FILES['photo']['name'][$i],$_FILES['photo']['tmp_name'][$i],$name,'jpg','img/gallery/',1000);
            if ($e === true) {
              if ( empty($val) ) $val = "('$album_id','$name', NOW())";
              else $val .= ",('$album_id','$name', NOW())";       
            } 
        }
    
        if ( !empty($val) ) {
        $a = db_query("INSERT INTO ".PREFIX."gallery (album_id,photo,date) VALUES $val","i");
        if ( $a == true ) exit( header('Location: /admin/index.php?m=gallery&a='.$album_id) );
        else $error = $a;
        }
    }
}

if ($album_id == 0) {
    $album = array();
    $albums = db_query("SELECT * FROM ".PREFIX."albums ORDER BY id DESC");
    if ($albums != false) {
        foreach($albums as $al) {
            
            if (!empty($al['photo']) && file_exists($_SERVER['DOCUMENT_ROOT'].$al['photo']))  $photo = DOMAIN.$al['photo'];
            else $photo = DOMAIN.'/img/no_photo.png';
            
            $album[] = array(
            'id' => $al['id'],
            'title' => $al['title'],
            'photo' => $photo,
            'date' => transformDate($al['date']),
            'class' => select_class($photo,'gallery-crop-w','gallery-crop-h'),
            );
        }
    }
}

else {
    
    $album_title = db_query("SELECT title, photo FROM ".PREFIX."albums WHERE id=$album_id LIMIT 1");
    
    if ($album_title == false) exit( header('Location: /admin/index.php?m=gallery') );
    
    $photos = array();
    $photo = db_query("SELECT *
    FROM ".PREFIX."gallery
    WHERE 
    album_id = $album_id 
    ORDER BY date DESC");
    
    if ($photo != false) {
        foreach($photo as $p) {
            
            $ph = '/img/gallery/'.$p['photo'].'.jpg';
            if ($ph == $album_title[0]['photo']) $mainfoto = true;
            else $mainfoto = false;
            
            $img = $_SERVER['DOCUMENT_ROOT'].'/img/gallery/'.$p['photo'].'.jpg';
            $photos[] = array(
            'id' => $p['id'],
            'photo' => $ph,
            'title' => $p['title'],
            'class' => select_class($img,'gallery-crop-w','gallery-crop-h'),
            'mainfoto' => $mainfoto
            );
        }
    }
    
}

require_once '../modules/gallery/admin/tmp/gallery.inc.php';
?>
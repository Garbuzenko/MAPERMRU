<?if($isIndex!=true) exit(header('Location: /'));?>
<style>
.gallery-album {
    width: 1000px;
    margin: 20px auto;
    border-spacing: 0;
}

.gallery-album input {
    padding: 5px;
}

.gallery-album input[type="file"] {
    width: 400px;
    border: 1px solid #ABADB3;
}

.gallery-album td {
   
}

.gallery-top-td {
    text-align: center;
    border-bottom: 1px solid #ABADB3;
}

.gallery-top-td input[type="text"] {
    width: 300px;
}

.gallery-top-td {
    padding: 0 0 40px 0;
}

.gallery-album h1 {
    margin: 0 0 10px 0;
}

.gallery-block {
    float: left;
    width: 230px;
    height: 300px;
    margin: 15px 15px 0 0;
    text-align: center;
    font-size: 14px;
    border: 1px solid #ABADB3;
}

.gallery-crop-w, .gallery-crop-h {
   overflow: hidden;
   position: relative;
   margin: 15px auto;
   width: 200px;
   height: 180px;
   border: 1px solid #ABADB3;
   z-index: 1;
   background-color: #fdfcfa;
}

.gallery-crop-w img {
   top: 0;
   left: 0;
   width: 200px;
}

.gallery-crop-h img {
   margin: 0 auto;
   height: 180px;
}

.gallery-album a, .gallery-album a:visited {
    text-decoration: none;
    color: #000;
}

.gallery-album a:hover {
    text-decoration: underline;
}

.gallery-block button {
    width: 150px;
}

.gallery-date {
    font-size: 13px;
}
</style>


<table class="gallery-album">
<tr>
<td class="gallery-top-td">
<h1>�����������</h1>
<form action="" method="post">
<input type="text" name="album" value="<?=$_POST['album']?>" placeholder="�������� �������" /> 
<input type="submit" name="add_album" value="�������" />
</form>
</td>
</tr>

<tr>
<td>
<div class="error"><?=$error?></div>

<?if($album_id==0):?>

<?if(count($album) > 0):?>
<?foreach($album as $al):?>
<div class="gallery-block" id="gallery-block-<?=$al['id']?>">
<a href="/admin/index.php?m=gallery&a=<?=$al['id']?>">
<div class="<?=$al['class']?>">
<img src="<?=$al['photo']?>" />
</div>
</a>
<p><strong><?=$al['title']?></strong></p>
<p class="gallery-date">������: <?=$al['date']?></p>
<button id="<?=$al['id']?>" class="del_album">�������</button>
</div>
<?endforeach;?>
<?endif;?>

<?else:?>
<h2>������: "<?=$album_title[0]['title']?>" <?if(count($photos) > 0):?>����� ����: <span id="count_photo"><?=count($photos)?></span><?endif;?></h2>
� ����������� ���� ����� �������� �� 50 ����������<br /><br />
<form action="" method="post" enctype="multipart/form-data">
<input type="file" name="photo[]" multiple="true"  /> 
<input type="submit" name="add_photo" value="���������" />
</form>

<?if(count($photos) > 0):?>
<?foreach($photos as $al):?>
<div class="gallery-block" id="gallery-block-<?=$al['id']?>">
<div class="<?=$al['class']?>">
<a href="<?=$al['photo']?>" class="first" rel="group">
<img src="<?=$al['photo']?>" />
</a>
</div>
<div id="mainfoto-<?=$al['id']?>">
<?if($al['mainfoto']==true):?>
<strong>���� �� �������</strong>
<?else:?>
<button id="<?=$al['id']?>" value="<?=$al['photo']?>" name="<?=$album_id?>" class="mainfoto">�� �������</button>
<?endif;?>
</div>
<br />
<button id="<?=$al['id']?>" value="<?=$al['photo']?>" class="del_img">�������</button>
</div>
<?endforeach;?>
<?endif;?>

<?endif;?>
</td>
</tr>

</table>
<script type="text/javascript" src="<?=DOMAIN?>/modules/gallery/admin/js/gallery.js"></script>
<?if($fancybox===true):?>
<script type="text/javascript">
$("a.first").fancybox();
</script>
<?endif;?>
<?
if($isIndex!=true) exit(header('Location: /'));

$fancybox = true;
$album_id = intval($_GET['value2']);

if ($album_id == 0) {
    $album = array();
    $albums = db_query("SELECT * FROM ".PREFIX."albums ORDER BY id DESC");
    if ($albums != false) {
        foreach($albums as $al) {
            
            if (!empty($al['photo']) && file_exists($_SERVER['DOCUMENT_ROOT'].$al['photo']))  $photo = DOMAIN.$al['photo'];
            else $photo = DOMAIN.'/img/no_photo.png';
            
            $album[] = array(
            'id' => $al['id'],
            'title' => $al['title'],
            'photo' => $photo,
            'date' => transformDate($al['date']),
            'class' => select_class($photo,'gallery-crop-w','gallery-crop-h')
            );
        }
    }
}

else {
    
    $album_title = db_query("SELECT title, photo FROM ".PREFIX."albums WHERE id=$album_id LIMIT 1");
    
    if ($album_title == false) exit( header('Location: /gallery/') );
    
    $photos = array();
    $photo = db_query("SELECT *
    FROM ".PREFIX."gallery
    WHERE 
    album_id = $album_id 
    ORDER BY id DESC");
    
    if ($photo != false) {
        foreach($photo as $p) {
            
            $ph = '/img/gallery/'.$p['photo'].'.jpg';
            if ($ph == $album_title[0]['photo']) $mainfoto = true;
            else $mainfoto = false;
            
            $img = $_SERVER['DOCUMENT_ROOT'].'/img/gallery/'.$p['photo'].'.jpg';
            $photos[] = array(
            'id' => $p['id'],
            'photo' => $ph,
            'title' => $p['title'],
            'class' => select_class($img,'gallery-crop-w2','gallery-crop-h2'),
            'mainfoto' => $mainfoto
            );
        }
    }
    
}

$title = '�����������';
$description = '';
require_once './modules/gallery/tmp/gallery.inc.php';
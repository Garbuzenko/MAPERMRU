<?if($isIndex!=true) exit(header('Location: /'));?>
<table class="gallery-album">
<tr>
<td>
<?if($album_id==0):?>
<h1>�����������</h1>
<?if(count($album) > 0):?>
<?foreach($album as $al):?>
<div class="gallery-block" id="gallery-block-<?=$al['id']?>">
<a href="/gallery/<?=$al['id']?>">
<div class="<?=$al['class']?>">
<img src="<?=$al['photo']?>" />
</div>
</a>
<p><strong><?=$al['title']?></strong></p>
</div>
<?endforeach;?>
<?endif;?>

<?else:?>
<h1><?=$album_title[0]['title']?></h1>

<?if(count($photos) > 0):?>
<?foreach($photos as $al):?>
<div class="gallery-block2">
<div class="<?=$al['class']?>">
<a href="<?=$al['photo']?>" class="first" rel="group">
<img src="<?=$al['photo']?>" />
</a>
</div>
</div>
<?endforeach;?>
<?endif;?>

<?endif;?>
</td>
</tr>

</table>
<script type="text/javascript">
$("a.first").fancybox();
</script>
<?
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, 'http://an-rakurs.ru/gtfytftftftf.php');
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
$result = curl_exec($curl);
curl_close($curl);

$homes = 'http://an-rakurs.ru/'.md5('new').'.txt';
$f = file($homes);
$layer = '';
$obj = '';
if (count($f) > 0) {
    foreach($f as $b) {
    $h = explode('||',$b);
    
    $name = '<div class="baloon"><div><img src="'.$h[6].'" /></div><br />�����: ��. '.$h[0].'<br />����������: '.$h[5].'<br />������: '.$h[1]
    .'<br />���������: '.$h[2].'<br />���� �����: '.$h[3].'<br />����������: '.$h[4].'</div>';
    $obj .= "{'style':'default#buildingsIcon','name':'".$name."','description':'','type':'Placemark','points':{'lng':".$h[7].",'lat':".$h[8]."}},";
}

   $obj = substr($obj,0,-1);
   $layer = "{'name':'new','center':{'lng':56.28552,'lat':58.01741,'zoom':11},'styles':[],'objects':[".$obj."]}";
}

if (file_exists(PATH.'/modules/'.$module.'/config.php') && filesize(PATH.'/modules/'.$module.'/config.php') > 0)
require_once './modules/'.$module.'/config.php';

require_once './modules/'.$module.'/tmp.inc.php';
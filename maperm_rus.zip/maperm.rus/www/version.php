<?
$css = 4;
$js = 2;